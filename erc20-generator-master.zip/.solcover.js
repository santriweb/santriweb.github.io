module.exports = {
  norpc: true,
  testCommand: 'npm run hardhat:test',
  compileCommand: 'npm run hardhat:compile',
  skipFiles: [
    'mocks'
  ],
};
